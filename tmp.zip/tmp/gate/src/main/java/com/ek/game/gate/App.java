package com.ek.game.gate;

import com.ek.game.core.Application;
import com.ek.game.core.Core;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class App {
    private static Application server;
    public static Application getServer(){return server;}
    public static void main(String[] args) {
        // 创建服务器
        server = Core.createApp("server_config.xml", App.class);
        // 启动服务器
        server.start();
    }
}
