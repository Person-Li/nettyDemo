package com.ek.game.gate.route;

import com.ek.game.core.route.RequestRoute;
import com.ek.game.core.route.RouteBase;
import com.ek.game.core.route.Router;
import com.ek.game.core.service.http.HttpRequestImpl;
import com.ek.game.core.service.http.HttpResponseImpl;
import com.ek.game.db.DBManager;
import com.ek.game.db.dao.UserMapper;
import com.ek.game.db.pojo.User;

@Router(url="/Test")
public class Test extends RouteBase {

    @RequestRoute(url="/getUrl")
    public void getUrl(HttpRequestImpl req, HttpResponseImpl res) throws InterruptedException {
        res.appendBody("呵呵呵");
        System.out.println("111");
        System.out.println("222");
        //UserMapper userMapper = DBManager.getInstance().getMapper(UserMapper.class);
        //User user = userMapper.selectByPrimaryKey("id1");
        //System.out.println("222" + user.getId());
    }

    @RequestRoute(url="/getUrl1", method = "POST")
    public void getUrl1(HttpRequestImpl req, HttpResponseImpl res){
        res.appendBody("啊哈哈哈");
        System.out.println("getUrl1 args=");
    }
}
