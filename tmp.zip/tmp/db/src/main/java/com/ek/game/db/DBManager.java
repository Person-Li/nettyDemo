package com.ek.game.db;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;

public class DBManager {
    private SqlSession sqlSession;

    private static DBManager manager = null;
    public static DBManager getInstance(){
        if (manager == null){
            manager = new DBManager();
        }
        return manager;
    }

    public void init() throws IOException {
        // 读取配置文件
        InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("mybatis-config.xml");
        // 构建sqlSessionFactory
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        // 获取sqlSession
        sqlSession = sqlSessionFactory.openSession();
    }

    public void stop(){
        sqlSession.close();;
    }

    public <T> T getMapper(Class<T> mapperClass){return sqlSession.getMapper(mapperClass);}
}
