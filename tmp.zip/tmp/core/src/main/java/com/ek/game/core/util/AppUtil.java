package com.ek.game.core.util;

import com.ek.game.core.Application;

import java.util.HashMap;
import java.util.Map;

public class AppUtil {
    public static void defaultConfiguration(Application app){

    }

    Map<String, String> parseArgs (String[] args) {
        Map<String, String> argsMap = new HashMap<>();
        int mainPos = 1;

        while (args[mainPos].indexOf("--") > 0) {
            mainPos++;
        }
        argsMap.put("main", args[mainPos]);
        return argsMap;
    };
}
