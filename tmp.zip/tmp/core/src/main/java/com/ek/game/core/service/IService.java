package com.ek.game.core.service;

/**
 * 基础服务
 */
public interface IService {
    public String getName();
    public void startup() throws Exception;
    public void shutdown() throws Exception;
}
