package com.ek.game.core.config;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 * 基本配置
 */
@Root
public class NetServiceConfig {

    @Element(required = false)
    private boolean tcpNoDelay = true;

    boolean getTcpNoDelay(){return tcpNoDelay;}
}
