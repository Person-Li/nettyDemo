package com.ek.game.core.service.http;

import com.ek.game.core.manager.RouteManager;
import io.netty.channel.*;
import io.netty.handler.codec.http.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;

/**
 * 默认读取全部，不使用trunked
 */
public class HttpServerHandler extends SimpleChannelInboundHandler<Object> {
    /** 输出日志 */
    private static final Logger LOG = LoggerFactory.getLogger(HttpServerHandler.class);

    private static final String FAVICON_ICO = "/favicon.ico";

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, Object msg) throws Exception {
        if (msg instanceof HttpRequest) {
            HttpRequest request = (HttpRequest) msg;
            // 屏蔽干扰
            if (request.uri().equals(FAVICON_ICO)) return;
            // 记录起始时间
            long begin = System.currentTimeMillis();
            // 创建req res
            HttpRequestImpl httpRequestImpl = new HttpRequestImpl(request);
            HttpResponseImpl httpResponseIml = new HttpResponseImpl(HttpVersion.HTTP_1_1, HttpResponseStatus.OK);
            // 获取执行方法
            Method m = RouteManager.getInstance().getRouteMethod((httpRequestImpl.getMethod().name()), httpRequestImpl.getRequestPath());
            if (m == null){
                // 未找到路由方法
                LOG.warn(String.format("Thread[%s] messageReceived [%s] - NOT FOUND",
                        Thread.currentThread().getName(), httpRequestImpl.getRequestPath()));
                httpResponseIml.setStatus(HttpResponseStatus.NOT_FOUND);
                writeResponse(httpResponseIml, httpRequestImpl, ctx);
                return;
            }
            // 执行方法
            try {
                Object o = m.getDeclaringClass().newInstance();
                m.invoke(o, httpRequestImpl, httpResponseIml);
            } catch (InstantiationException | IllegalAccessException e) {
                e.printStackTrace();
            }
            // 执行response
            writeResponse(httpResponseIml, httpRequestImpl, ctx);
            long cost = System.currentTimeMillis() - begin;
            if (cost > 100L){
                LOG.warn(String.format("Thread[%s] messageReceived [%s] cost %d ms",
                        Thread.currentThread().getName(), httpRequestImpl.getRequestPath(), cost));
            }else{
                LOG.info(String.format("Thread[%s] messageReceived [%s] cost %d ms",
                        Thread.currentThread().getName(), httpRequestImpl.getRequestPath(), cost));
            }
        }
    }


    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) {
        ctx.flush();
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        cause.printStackTrace();
        ctx.close();
    }

    private void writeResponse(HttpResponseImpl httpResponseImpl, HttpRequestImpl httpRequestImpl, ChannelHandlerContext ctx) {
        boolean keepAlive = HttpUtil.isKeepAlive(httpRequestImpl.getHttpRequest());
        String cookieString = httpRequestImpl.getHttpRequest().headers().get(HttpHeaderNames.COOKIE);
        HttpResponse httpResponse = httpResponseImpl.getResponse(keepAlive, cookieString);
        if (!keepAlive) {
            ctx.writeAndFlush(httpResponse).addListener(ChannelFutureListener.CLOSE);
        } else {
            ctx.writeAndFlush(httpResponse);
        }
    }
}
