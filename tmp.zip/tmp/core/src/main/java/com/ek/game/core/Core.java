package com.ek.game.core;

public class Core {
    public static Application app;

    public static Application createApp(String configName, Class<?> startClass){
        app = new Application();
        app.init(configName, startClass);
        return app;
    }
}
