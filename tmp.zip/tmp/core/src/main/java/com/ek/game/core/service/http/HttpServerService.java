package com.ek.game.core.service.http;

import com.ek.game.core.manager.ConfigManager;
import com.ek.game.core.service.IService;
import com.ek.game.core.config.ThreadPoolExecutorConfig;
import com.ek.game.core.util.Constants;
import com.ek.game.core.thread.ThreadNameFactory;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HttpServerService implements IService {

    private final Logger LOG = LoggerFactory.getLogger(HttpServerService.class);
    private EventLoopGroup bossGroup;
    private EventLoopGroup workerGroup;

    private final ThreadNameFactory bossThreadNameFactory;
    private final ThreadNameFactory workerThreadNameFactory;
    private final ChannelInitializer channelInitializer;

    private int serverPort;

    private boolean isRunning = false;

    public HttpServerService(int serverPort) {
        this.bossThreadNameFactory = new ThreadNameFactory(Constants.Thread.NET_HTTP_BOSS);
        this.workerThreadNameFactory = new ThreadNameFactory(Constants.Thread.NET_HTTP_WORKER);
        this.serverPort = serverPort;
        ThreadPoolExecutorConfig threadPoolExecutorConfig = ConfigManager.getInstance().getResourceConfig(ConfigManager.HTTP_THREAD_EXECUTOR_CONFIG, ThreadPoolExecutorConfig.class);
        this.channelInitializer = new HttpServerChannelInitializer(threadPoolExecutorConfig);
    }

    @Override
    public String getName() {
        return "HttpServerService";
    }

    @Override
    public void startup() throws Exception {
        synchronized (this) {
            if (!isRunning) {
                isRunning = true;
                bossGroup = new NioEventLoopGroup(1, bossThreadNameFactory);
                workerGroup = new NioEventLoopGroup(0, workerThreadNameFactory);
                ServerBootstrap serverBootstrap = new ServerBootstrap();
                serverBootstrap = serverBootstrap.group(bossGroup, workerGroup);
                serverBootstrap.channel(NioServerSocketChannel.class)
                        .option(ChannelOption.SO_BACKLOG, 1024)
                        .childOption(ChannelOption.SO_REUSEADDR, true) //重用地址
                        .childOption(ChannelOption.SO_RCVBUF, 65536)
                        .childOption(ChannelOption.SO_SNDBUF, 65536)
                        .childOption(ChannelOption.TCP_NODELAY, true)
                        .childOption(ChannelOption.SO_KEEPALIVE, true)
                        .childOption(ChannelOption.ALLOCATOR, new PooledByteBufAllocator(false))  // heap buf 's better
                        .childOption(ChannelOption.CONNECT_TIMEOUT_MILLIS, 1000)
                        .handler(new LoggingHandler(LogLevel.INFO))
                        .childHandler(channelInitializer);
                // bootstrap.setOption("child.tcpNoDelay", Boolean.valueOf(true));
                // bootstrap.setOption("child.keepAlive", Boolean.valueOf(true));
                // bootstrap.setOption("child.reuseAddress", Boolean.valueOf(true));
                // bootstrap.setOption("child.connectTimeoutMillis", Integer.valueOf(100));
                ChannelFuture serverChannelFuture = serverBootstrap.bind(serverPort).sync();

                serverChannelFuture.channel().closeFuture().addListener(ChannelFutureListener.CLOSE);

                LOG.info(String.format("Thread[%s] Service[%s] startup", Thread.currentThread().getName(), getName()));
                //serverChannelFuture.channel().closeFuture().sync();
            }
        }
    }

    @Override
    public void shutdown() throws Exception{
        if(bossGroup != null){
            bossGroup.shutdownGracefully();
        }
        if(workerGroup != null){
            workerGroup.shutdownGracefully();
        }
        LOG.info(String.format("Thread[%s] Service[%s] shutdown", Thread.currentThread().getName(), getName()));
    }
}
