package com.ek.game.core.components;

import com.ek.game.core.service.http.HttpServerService;
import com.ek.game.core.util.SysUtil;
import com.ek.game.db.DBManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class MysqlComponent extends AComponent {
    private final Logger LOG = LoggerFactory.getLogger(HttpServerService.class);
    @Override
    public void start() {
        try {
            DBManager.getInstance().init();
            LOG.info("Component [MysqlComponent] started");
        } catch (IOException e){
            SysUtil.exit(MysqlComponent.class, e, "Component [MysqlComponent] start error");
        }

    }

    @Override
    public void afterStart() {

    }

    @Override
    public void stop() {
        DBManager.getInstance().stop();
        LOG.info("Component [MysqlComponent] stopped");
    }
}
