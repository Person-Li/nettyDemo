package com.ek.game.core.util;

public class Constants {
    public static final int NONE = 0;

    // 服务器状态
    public static final class ServerState {
        public static final int INITED = 1;
        public static final int BEFORE_START = 2;
        public static final int START = 3;
        public static final int STARTED = 4;
        public static final int STOPED = 5;
    }

    public static final class Thread{
        public static final String NET_TCP_BOSS ="net_tcp_boss";
        public static final String NET_TCP_WORKER ="net_tcp_worker";
        public static final String GAME_MESSAGE_QUEUE_EXCUTE="game_message_queue";
        public static final String NET_UDP_WORKER ="net_udp_worker";
        public static final String NET_UDP_MESSAGE_PROCESS ="net_udp_message_process";
        public static final String NET_RPC_BOSS ="net_rpc_boss";
        public static final String NET_RPC_WORKER ="net_rpc_worker";
        public static final String START_FINISHED ="start_finished";
        public static final String DETECT_RPCPENDING ="detect_rpcpending";
        public static final String GAME_ASYNC_CALL = "game_async_call";
        public static final String RPC_HANDLER = "rpc_handler";
        public static final String ASYNC_EVENT_WORKER = "async_event_worker";
        public static final String ASYNC_EVENT_HANDLER = "async_event_handler";
        public static final String UPDATE_EXECUTOR_SERVICE = "UpdateExecutorService";
        public static final String NET_PROXY_BOSS ="net_proxy_boss";
        public static final String NET_PROXY_WORKER ="net_proxy_worker";
        public static final String NET_HTTP_BOSS ="net_http_boss";
        public static final String NET_HTTP_WORKER ="net_http_worker";

        public static final String NET_WEB_SOCKET_BOSS ="net_web_socket_boss";
        public static final String NET_WEB_SOCKET_WORKER ="net_web_socket_worker";

        private Thread() {
        }
    }
}
