package com.ek.game.core;

public interface ServerInfo {
    String id = null;
    String serverType = null;
    String host = null;
    String port = null;
    String clientHost = null;
    String clientPort = null;
    String httpHost = null;
    String httpPort = null;
    Boolean frontend = false;
}
