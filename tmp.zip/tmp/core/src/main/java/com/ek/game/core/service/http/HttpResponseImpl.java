package com.ek.game.core.service.http;

import com.alibaba.fastjson.JSONObject;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.http.*;
import io.netty.handler.codec.http.cookie.Cookie;
import io.netty.handler.codec.http.cookie.ServerCookieDecoder;
import io.netty.util.CharsetUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import io.netty.handler.codec.http.HttpHeaderNames;

/**
 * http返回消息
 */
public class HttpResponseImpl {

    private static final Logger LOG = LoggerFactory.getLogger(HttpResponseImpl.class);

    private final StringBuffer bodyStringBuffer;
    private String contentType = "text/html; charset=UTF-8";
    private HttpResponseStatus httpResponseStatus = HttpResponseStatus.OK;
    private HttpVersion httpVersion;

    public HttpResponseImpl(HttpVersion httpVersion, HttpResponseStatus httpResponseStatus) {
        this.httpVersion = httpVersion;
        bodyStringBuffer = new StringBuffer();
    }

    public void setStatus(HttpResponseStatus httpResponseStatus){this.httpResponseStatus = httpResponseStatus;}

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public HttpResponseImpl appendBody(String s) {
        bodyStringBuffer.append(s);
        return this;
    }

    public HttpResponseImpl appendBody(Object obj){
        bodyStringBuffer.append(JSONObject.toJSONString(obj));
        return this;
    }

    public DefaultFullHttpResponse getResponse(boolean keepAlive, String cookieString){
        byte[] bytes = bodyStringBuffer.toString().getBytes(CharsetUtil.UTF_8);
        ByteBuf buf = Unpooled.wrappedBuffer(bytes);
        DefaultFullHttpResponse httpResponse = new DefaultFullHttpResponse(this.httpVersion, this.httpResponseStatus, buf);
        HttpHeaders headers = httpResponse.headers();
        headers.set("Server", "HttpServer (" + "Netty 4.1.16" + ')');
        headers.set("Cache-Control", "private");
        headers.set("Content-Type", contentType);
        headers.set("Connection", "keep-alive");
        headers.set("Keep-Alive", "500");
        headers.set("Date", new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz").format(new Date()));
        headers.set("Last-Modified", new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz").format(new Date()));

        headers.setInt(HttpHeaderNames.CONTENT_LENGTH, httpResponse.content().readableBytes());
        if (keepAlive) {
            // Add keep alive header as per:
            // - http://www.w3.org/Protocols/HTTP/1.1/draft-ietf-http-v11-spec-01.html#Connection
            headers.set(HttpHeaderNames.CONNECTION, HttpHeaderValues.KEEP_ALIVE);
        }

        // Encode the cookie.
        if (cookieString != null) {
            Set<Cookie> cookies = ServerCookieDecoder.STRICT.decode(cookieString);
            if (!cookies.isEmpty()) {
                // Reset the cookies if necessary.
                for (io.netty.handler.codec.http.cookie.Cookie cookie: cookies) {
                    headers.add(HttpHeaderNames.SET_COOKIE, io.netty.handler.codec.http.cookie.ServerCookieEncoder.STRICT.encode(cookie));
                }
            }
        } else {
            // Browser sent no cookie.  Add some.
            headers.add(HttpHeaderNames.SET_COOKIE, io.netty.handler.codec.http.cookie.ServerCookieEncoder.STRICT.encode("key1", "value1"));
            headers.add(HttpHeaderNames.SET_COOKIE, io.netty.handler.codec.http.cookie.ServerCookieEncoder.STRICT.encode("key2", "value2"));
        }

        return httpResponse;
    }
}
