package com.ek.game.core.route;

public class RouteBase {

}
