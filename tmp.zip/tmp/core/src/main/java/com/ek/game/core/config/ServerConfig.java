package com.ek.game.core.config;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root
public class ServerConfig {
    @Element
    private String id;
    @Element
    private String serverType;
    @Element
    private String host;
    @Element
    private int port;
    @Element(required = false)
    private String clientHost = null;
    @Element(required = false)
    private int clientPort = 0;
    @Element(required = false)
    private String httpHost = null;
    @Element(required = false)
    private int httpPort = 0;
    @Element(required = false)
    private boolean httpComponentEnable = false;
    @Element(required = false)
    private boolean tcpComponentEnable = false;
    @Element(required = false)
    private boolean mysqlComponentEnable = false;

    public String getId(){return id;}
    public String getServerType(){return serverType;}
    String getHost(){return host;}
    int getPort(){return port;}
    String getClientHost(){return clientHost;}
    int getClientPort(){return clientPort;}
    String getHttpHost(){return httpHost;}
    public int getHttpPort(){return httpPort;}
    public boolean getHttpComponentEnable(){return this.httpComponentEnable;}
    public boolean getTcpComponentEnable(){return this.tcpComponentEnable;}
    public boolean getMysqlComponentEnable(){return this.mysqlComponentEnable;}
}
