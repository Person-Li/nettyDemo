/**
 * 应用基础类，记录服务器的基本信息，初始化服务器，加载配置，加载
 */

package com.ek.game.core;

import com.ek.game.core.components.AComponent;
import com.ek.game.core.components.HttpServerComponent;
import com.ek.game.core.components.MysqlComponent;
import com.ek.game.core.config.ServerConfig;
import com.ek.game.core.manager.ConfigManager;

import com.ek.game.core.manager.RouteManager;
import com.ek.game.core.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Application {
    private static final Logger LOGGER = LoggerFactory.getLogger(Application.class);
    private String serverId = null;                     // 服务器ID
    private String serverType = null;                   // 服务器类型
    private ServerConfig curServer = null;              // 服务器信息
    private long startTime = 0;                         // 服务器启动时间

    private String base;

    private ServerConfig master = null;                   // Master服务器信息
    private Map<String, ServerConfig> servers = null;     // 其他服务器信息

    private int state = Constants.NONE;                 // 服务器状态

    private Map<String, AComponent> components = new ConcurrentHashMap<>();
    private Map<String, Object> settings = new ConcurrentHashMap<>();

    // 初始化app
    void init(String configName, Class<?> startClass){
        // 初始化项目跟目录
        File file = new File(System.getProperty("user.dir"));
        LOGGER.debug("user.dir: {}", System.getProperty("user.dir"));
        this.base = file.getPath();

        // 初始化管理器
        // 路由管理器
        RouteManager.getInstance().init(startClass.getPackage().getName());
        // 配置管理器
        ConfigManager.getInstance().init();

        // 加载配置
        curServer = ConfigManager.getInstance().getConfig(configName, ServerConfig.class);
        this.serverId = curServer.getId();
        this.serverType = curServer.getServerType();

        // 加载默认组件
        this.loadDefaultComponents();

        // 修改服务器状态
        this.state = Constants.ServerState.INITED;

        LOGGER.info(String.format("Server [%s] init", this.serverId));
    }

    // 获取、设置项目基础路径
    String getBase(){return this.base;}

    // 加载过滤器
    void filter(){}
    void before(){}
    void after(){}
    void addFilter(){}

    // 加载rpc过滤器
    void rpcFilter(){}
    void rpcBefore(){}
    void rpcAfter(){}

    // 加载组件
    void loadComponent(String name, AComponent component){
        components.put(name, component);
    }
    // 加载默认组件
    private void loadDefaultComponents(){
        if (curServer.getHttpComponentEnable()){
            loadComponent("HttpServerComponent", new HttpServerComponent(curServer.getHttpPort()));
        }
        if (curServer.getMysqlComponentEnable()){
            loadComponent("MysqlComponent", new MysqlComponent());
        }
    }

    // 设置路由方法
    void route(){};

    // 生命周期回调
    public void start(){
        // 记录启动时间
        this.startTime = System.currentTimeMillis();
        // 检查状态
        if(this.state > Constants.ServerState.INITED) {
            LOGGER.error("server state error:" + this.state);
            return;
        }
        // 组件生命周期
        for(Map.Entry<String, AComponent> entry : components.entrySet()){
            entry.getValue().start();
        }

        // 修改状态继续执行
        this.state = Constants.ServerState.START;
        LOGGER.info(String.format("Server [%s] start", this.serverId));
        this.afterStart();
    }
    private void afterStart(){
        // 组件生命周期
        for(Map.Entry<String, AComponent> entry : components.entrySet()){
            entry.getValue().afterStart();
        }
        this.state = Constants.ServerState.STARTED;

        LOGGER.info(String.format("Server [%s] afterStart", this.serverId));
    }
    void stop(){
        // 组件生命周期
        for(Map.Entry<String, AComponent> entry : components.entrySet()){
            entry.getValue().stop();
        }

        this.state = Constants.ServerState.STOPED;

        LOGGER.info(String.format("Server [%s] stop", this.serverId));
    }

    // 添加服务器
    void addServers(){}
    void removeServers(){}
    void replaceServers(){}

    // 基础方法
    void set(String key, Object object){
        settings.put(key, object);
    }
    void get(String key){
        settings.get(key);
    }
    ServerConfig getMaster(){return this.master;}
    ServerConfig getCurServer(){return this.curServer;}
    String getServerId(){return this.serverId;}
    String getServerType(){return this.serverType;}
    void getServers(){}
    boolean isFrontend(){return false;}
    boolean isBackend(){return false;}
    long getStartTime(){return this.startTime;}
}
