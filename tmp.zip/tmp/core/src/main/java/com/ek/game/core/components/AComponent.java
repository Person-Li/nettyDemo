package com.ek.game.core.components;

public abstract class AComponent {
    public abstract void start();
    public abstract void afterStart();
    public abstract void stop();
}
