package com.ek.game.core.manager;

import com.ek.game.core.util.FileUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;

public class ConfigManager {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigManager.class);

    public static final String HTTP_SERVER_CONFIG = "net_server_config_http.xml";
    public static final String HTTP_THREAD_EXECUTOR_CONFIG = "thread_executor_config_http.xml";

    public void init(){ };

    private static ConfigManager configManager = null;
    public static ConfigManager getInstance(){
        if (configManager == null){
            configManager = new ConfigManager();
        }
        return configManager;
    }


    public <T> T  getConfig(String fileName, Class<T> configClass){
        File file = new File(System.getProperty("user.dir"));
        LOGGER.debug("user.dir: {}", System.getProperty("user.dir"));
        String path = file.getPath() + File.separatorChar + "config";
        return FileUtil.getConfigXML(path, fileName, configClass);
    }

    public <T> T  getResourceConfig(String fileName, Class<T> configClass){
        String fullFileName = FileUtil.getResourcesConfigPath(fileName);
        return FileUtil.getConfigXML(fullFileName, configClass);
    }
}
