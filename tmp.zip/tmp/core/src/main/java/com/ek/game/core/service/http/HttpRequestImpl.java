package com.ek.game.core.service.http;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.http.*;
import org.apache.commons.codec.CharEncoding;
import org.apache.commons.codec.Charsets;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class HttpRequestImpl {
    private final HttpVersion version;
    private final HttpMethod method;
    private final String requestedPath;
    private final String queryString;
    private final Map<String, String> headers;
    private final Map<String, List<String>> parameters;
    private HttpRequest httpRequest;
    private ByteBuf content;

    public HttpRequestImpl(HttpRequest httpRequest) {
        this.version = httpRequest.protocolVersion();
        this.method = httpRequest.method();
        this.headers = new ConcurrentHashMap<>();

        QueryStringDecoder queryDecoder = new QueryStringDecoder(httpRequest.uri(), Charsets.toCharset(CharEncoding.UTF_8));
        this.requestedPath = queryDecoder.path();
        this.parameters = queryDecoder.parameters();
        this.queryString = queryDecoder.uri();

        if (httpRequest instanceof FullHttpRequest){
            FullHttpRequest fullHttpRequest = (FullHttpRequest)httpRequest;
            content = fullHttpRequest.content();
        }

        this.httpRequest = httpRequest;
    }

    public HttpRequest getHttpRequest(){return this.httpRequest;}

    public String getContentType() {
        return this.headers.get("content-type");
    }

    public boolean isKeepAlive() {
        return false;
    }

    public String getHeader(String name) {
        return this.headers.get(name);
    }

    public boolean containsHeader(String name) {
        return this.headers.containsKey(name);
    }

    public Map<String, String> getHeaders() {
        return this.headers;
    }

    public boolean containsParameter(String name) {
        return parameters.containsKey(name);
    }

    public String getParameter(String name) {
        List<String> temp = parameters.get(name);
        return temp == null?null:temp.get(0);
    }

    public Map<String, List<String>> getParameters() {
        return this.parameters;
    }

    public HttpMethod getMethod() {
        return this.method;
    }

    public String getRequestPath() {
        return this.requestedPath;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("HTTP REQUEST METHOD: ").append(this.method.name()).append('\n');
        sb.append("VERSION: ").append(this.version).append('\n');
        sb.append("PATH: ").append(this.requestedPath).append('\n');
        sb.append("QUERY:").append(this.queryString).append('\n');
        sb.append("--- HEADER --- \n");
        Iterator var2 = this.headers.entrySet().iterator();

        while(var2.hasNext()) {
            Map.Entry<String, String> entry = (Map.Entry)var2.next();
            sb.append((String)entry.getKey()).append(':').append((String)entry.getValue()).append('\n');
        }

        sb.append("--- PARAMETERS --- \n");
        Map<String, List<String>> parameters = this.getParameters();
        Iterator var9 = parameters.entrySet().iterator();

        while(var9.hasNext()) {
            Map.Entry<String, List<String>> entry = (Map.Entry)var9.next();
            String key = (String)entry.getKey();
            Iterator var6 = ((List)entry.getValue()).iterator();

            while(var6.hasNext()) {
                String value = (String)var6.next();
                sb.append(key).append(':').append(value).append('\n');
            }
        }

        return sb.toString();
    }

    public JSONObject getContentWithJSON(){
        String contentType = getContentType();
        if (content == null || contentType == null || !contentType.equals("application/json")) return null;
        String contentStr = content.toString(Charsets.toCharset(CharEncoding.UTF_8));
        return JSON.parseObject(contentStr);
    }

    public Map<String, List<String>> getContentWithUrlencoded(){
        String contentType = getContentType();
        if (content == null || contentType == null || !contentType.equals("application/x-www-form-urlencoded")) return null;
        String contentStr = content.toString(Charsets.toCharset(CharEncoding.UTF_8));
        QueryStringDecoder queryDecoder = new QueryStringDecoder(contentStr, false);
        return queryDecoder.parameters();
    }
}
