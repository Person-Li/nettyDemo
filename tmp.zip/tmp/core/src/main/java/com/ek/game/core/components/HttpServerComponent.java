package com.ek.game.core.components;

import com.ek.game.core.service.http.HttpServerService;
import com.ek.game.core.util.SysUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HttpServerComponent extends AComponent {
    private final Logger LOG = LoggerFactory.getLogger(HttpServerService.class);

    private HttpServerService httpServerService;
    public HttpServerComponent(int serverPort){
        httpServerService = new HttpServerService(serverPort);
    }

    @Override
    public void start() {
        try {
            this.httpServerService.startup();
            LOG.info("Component [HttpServerComponent] started");
        } catch (Exception e){
            SysUtil.exit(HttpServerComponent.class, e, "Component [HttpServerComponent] start error");
        }
    }

    @Override
    public void afterStart() {

    }

    @Override
    public void stop() {
        try {
            this.httpServerService.shutdown();
            LOG.info("Component [HttpServerComponent] stopped");
        } catch (Exception e){
            LOG.error("Component [HttpServerComponent] stop error");
            e.printStackTrace();
        }
    }
}
