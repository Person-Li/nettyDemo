package com.ek.game.core.manager;

import com.ek.game.core.route.RequestRoute;
import com.ek.game.core.route.Router;
import org.reflections.Reflections;
import org.reflections.scanners.FieldAnnotationsScanner;
import org.reflections.scanners.MethodAnnotationsScanner;
import org.reflections.scanners.SubTypesScanner;
import org.reflections.scanners.TypeAnnotationsScanner;
import org.reflections.util.ClasspathHelper;
import org.reflections.util.ConfigurationBuilder;
import org.reflections.util.FilterBuilder;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class RouteManager {
    private final Map<String, Method> getHandlerMethod = new ConcurrentHashMap<>();
    private final Map<String, Method> postHandlerMethod = new ConcurrentHashMap<>();

    private static RouteManager routeManager = null;
    public static RouteManager getInstance(){
        if (routeManager == null) routeManager = new RouteManager();
        return routeManager;
    }

    public void init(String routePackage){
        initRoute(routePackage + ".route");
    }

    // 初始化HTTP请求初始化路由
    private void initRoute(String routePackage){
        ConfigurationBuilder builder = new ConfigurationBuilder();
        builder.addUrls(ClasspathHelper.forPackage(routePackage));
        builder.setScanners(new TypeAnnotationsScanner(), new SubTypesScanner(),
                new MethodAnnotationsScanner(), new FieldAnnotationsScanner());
        builder.filterInputsBy(new FilterBuilder().includePackage(routePackage));

        Reflections f = new Reflections(builder);

        Set<Method> fcs = f.getMethodsAnnotatedWith(RequestRoute.class);
        for(Method m : fcs){
            Router router = m.getDeclaringClass().getDeclaredAnnotation(Router.class);
            RequestRoute requestRoute = m.getDeclaredAnnotation(RequestRoute.class);
            String requestUrl = router.url() + requestRoute.url();
            if (requestRoute.method().equals("GET")){
                getHandlerMethod.put(requestUrl, m);
            } else if (requestRoute.method().equals("POST")){
                postHandlerMethod.put(requestUrl, m);
            }
        }
    }
    // 获取HTTP请求路由
    public Method getRouteMethod(String methodType, String requestUrl){
        if (methodType.equals("GET")){
            return getHandlerMethod.get(requestUrl);
        }else if (methodType.equals("POST")){
            return postHandlerMethod.get(requestUrl);
        }
        return null;
    }
}
