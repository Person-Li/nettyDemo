package com.ek.game.core.thread.queue.executor;

import com.ek.game.core.thread.queue.action.Action;
import com.ek.game.core.thread.queue.action.DelayAction;

/**
 * 带延迟执行的线程执行器接口
 *
 */
public interface IDelayExecutor extends IExecutor<Action> {
	
	/**
	 * 执行延迟/定时 action
	 * @param delayAction
	 */
    void executeDelayAction(DelayAction delayAction);
}
